#!/usr/bin/env python3
"""
Nenek Di Dapur - Scene Editor (Full)
====================================
Mode:
  TAB          → ganti mode (PROPS / SPAWN / UI)
  S            → Save
  L            → Reload
  ESC          → Keluar (dengan konfirmasi jika ada perubahan)

PROPS mode:
  Klik kiri di list props (kanan) → pilih prop
  Klik kiri di scene → pilih prop terdekat / pindah
  Drag         → pindah prop
  Scroll / +/- → scale
  [ ]          → layer turun / naik
  Del          → hapus prop
  A            → tambah prop dari folder props (cycle)

SPAWN mode:
  Klik kiri    → tambah spawn point
  Drag titik   → pindah
  Klik kanan   → hapus
  0-3          → set layer

UI mode:
  Klik elemen UI → pilih
  Drag           → pindah
  Scroll         → ubah size (radius / width)

Semua tersimpan ke config/scene.json
"""

import pygame
import json
import os
from pathlib import Path
from copy import deepcopy

BASE = Path(__file__).parent
CONFIG_PATH = BASE / "config" / "scene.json"
ASSETS = BASE / "assets"
PROPS_DIR = ASSETS / "props"

# ================= COLORS =================
BG_DARK = (25, 20, 18)
PANEL = (40, 32, 28)
PANEL2 = (55, 45, 38)
ACCENT = (255, 180, 60)
GREEN = (80, 200, 100)
RED = (220, 80, 70)
BLUE = (80, 160, 255)
WHITE = (245, 240, 230)
YELLOW = (255, 230, 100)
GRAY = (120, 110, 100)

MODES = ["PROPS", "SPAWN", "UI"]

class Editor:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Nenek Di Dapur - Scene Editor")

        self.cfg = self.load()
        self.W = self.cfg["screen"]["width"]
        self.H = self.cfg["screen"]["height"]
        # Extra panel di kanan
        self.PANEL_W = 260
        self.screen = pygame.display.set_mode((self.W + self.PANEL_W, self.H))
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont("consolas", 15)
        self.font_sm = pygame.font.SysFont("consolas", 13)
        self.font_b = pygame.font.SysFont("consolas", 16, bold=True)

        self.mode = 0  # 0=PROPS 1=SPAWN 2=UI
        self.selected = None          # prop dict / spawn dict / ui key
        self.dragging = False
        self.dirty = False
        self.message = ""
        self.msg_timer = 0

        # Load all prop images
        self.prop_images = {}
        self.available_props = []
        self._scan_props()

        # Pre-render prop surfaces with current scale
        self.prop_surfs = {}
        self._rebuild_prop_surfs()

        self.running = True

    def load(self):
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)

    def save(self):
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(self.cfg, f, indent=2, ensure_ascii=False)
        self.dirty = False
        self.toast("Tersimpan!")

    def _scan_props(self):
        self.available_props = []
        if not PROPS_DIR.exists():
            PROPS_DIR.mkdir(parents=True)
        for f in sorted(PROPS_DIR.iterdir()):
            if f.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp"):
                try:
                    img = pygame.image.load(str(f)).convert_alpha()
                    rel = f"props/{f.name}"
                    self.prop_images[rel] = img
                    self.available_props.append(rel)
                except Exception as e:
                    print("Gagal load prop:", f, e)
        print(f"[Editor] {len(self.available_props)} props tersedia")

    def _rebuild_prop_surfs(self):
        self.prop_surfs = {}
        for p in self.cfg["props"]:
            key = p["image"]
            if key not in self.prop_images:
                continue
            base = self.prop_images[key]
            sc = p.get("scale", 1.0)
            if abs(sc - 1.0) > 0.01:
                w = max(1, int(base.get_width() * sc))
                h = max(1, int(base.get_height() * sc))
                self.prop_surfs[id(p)] = pygame.transform.smoothscale(base, (w, h))
            else:
                self.prop_surfs[id(p)] = base

    def toast(self, text, time=1.5):
        self.message = text
        self.msg_timer = time

    # ========== HELPERS ==========
    def prop_rect(self, p):
        surf = self.prop_surfs.get(id(p))
        if not surf:
            return pygame.Rect(p["x"]-10, p["y"]-10, 20, 20)
        r = surf.get_rect()
        if p.get("anchor", "center") == "center":
            r.center = (p["x"], p["y"])
        else:
            r.topleft = (p["x"], p["y"])
        return r

    def hit_prop(self, pos):
        # Cek dari layer tertinggi
        sorted_props = sorted(self.cfg["props"], key=lambda x: x.get("layer", 0), reverse=True)
        for p in sorted_props:
            if self.prop_rect(p).collidepoint(pos):
                return p
        return None

    def hit_spawn(self, pos):
        for s in self.cfg["spawn_points"]:
            if (s["x"] - pos[0])**2 + (s["y"] - pos[1])**2 < 144:
                return s
        return None

    def hit_ui(self, pos):
        ui = self.cfg["ui"]
        # grandma
        g = ui["grandma"]
        if (g["x"] - pos[0])**2 + (g["y"] - pos[1])**2 < (g["radius"] + 8)**2:
            return ("grandma", g)
        # bubble
        b = ui["bubble"]
        br = pygame.Rect(b["x"], b["y"], b["width"], b["height"])
        if br.collidepoint(pos):
            return ("bubble", b)
        # buttons
        for name, btn in ui["buttons"].items():
            r = pygame.Rect(btn["x"] - btn["w"]//2, btn["y"] - btn["h"]//2, btn["w"], btn["h"])
            if r.collidepoint(pos):
                return (f"btn_{name}", btn)
        return None

    # ========== DRAW ==========
    def draw_scene(self):
        # Clear scene area
        self.screen.fill(BG_DARK, (0, 0, self.W, self.H))

        # Draw props by layer
        sorted_props = sorted(self.cfg["props"], key=lambda x: x.get("layer", 0))
        for p in sorted_props:
            surf = self.prop_surfs.get(id(p))
            if not surf:
                continue
            r = self.prop_rect(p)
            self.screen.blit(surf, r)
            # selection outline
            if p is self.selected:
                pygame.draw.rect(self.screen, ACCENT, r.inflate(6, 6), 2)
                # center cross
                pygame.draw.line(self.screen, ACCENT, (p["x"]-8, p["y"]), (p["x"]+8, p["y"]), 1)
                pygame.draw.line(self.screen, ACCENT, (p["x"], p["y"]-8), (p["x"], p["y"]+8), 1)

        # Spawn points (always visible in SPAWN mode, faint otherwise)
        for s in self.cfg["spawn_points"]:
            is_sel = s is self.selected
            alpha_col = GREEN if is_sel else (YELLOW if self.mode == 1 else (100, 90, 50))
            pygame.draw.circle(self.screen, alpha_col, (s["x"], s["y"]), 9)
            pygame.draw.circle(self.screen, (0, 0, 0), (s["x"], s["y"]), 9, 2)
            if self.mode == 1 or is_sel:
                lab = self.font_sm.render(f"{s['id']}", True, WHITE)
                self.screen.blit(lab, (s["x"] + 11, s["y"] - 7))

        # UI elements
        ui = self.cfg["ui"]
        g = ui["grandma"]
        col = RED if self.selected == g else (200, 80, 80)
        pygame.draw.circle(self.screen, col, (g["x"], g["y"]), g["radius"], 2)
        pygame.draw.circle(self.screen, col, (g["x"], g["y"]), 4)
        self.screen.blit(self.font_sm.render("NENEK", True, col), (g["x"] - 20, g["y"] - g["radius"] - 16))

        b = ui["bubble"]
        col = BLUE if self.selected == b else (100, 160, 255)
        pygame.draw.rect(self.screen, col, (b["x"], b["y"], b["width"], b["height"]), 2)
        self.screen.blit(self.font_sm.render("BUBBLE", True, col), (b["x"], b["y"] - 14))

        for name, btn in ui["buttons"].items():
            is_sel = self.selected == btn
            col = ACCENT if is_sel else (180, 160, 120)
            r = pygame.Rect(btn["x"] - btn["w"]//2, btn["y"] - btn["h"]//2, btn["w"], btn["h"])
            pygame.draw.rect(self.screen, col, r, 2, border_radius=6)
            t = self.font_sm.render(btn.get("text", name), True, col)
            self.screen.blit(t, t.get_rect(center=r.center))

    def draw_panel(self):
        px = self.W
        self.screen.fill(PANEL, (px, 0, self.PANEL_W, self.H))

        # Mode tabs
        for i, m in enumerate(MODES):
            r = pygame.Rect(px + 8 + i * 80, 8, 76, 28)
            col = ACCENT if i == self.mode else PANEL2
            pygame.draw.rect(self.screen, col, r, border_radius=4)
            t = self.font_sm.render(m, True, BLACK if i == self.mode else WHITE)
            self.screen.blit(t, t.get_rect(center=r.center))

        y = 50
        mode_name = MODES[self.mode]
        self.screen.blit(self.font_b.render(f"MODE: {mode_name}", True, ACCENT), (px + 10, y))
        y += 28

        if self.mode == 0:  # PROPS
            self.screen.blit(self.font_sm.render("Props di scene:", True, GRAY), (px + 10, y))
            y += 20
            for i, p in enumerate(self.cfg["props"]):
                is_sel = p is self.selected
                col = ACCENT if is_sel else WHITE
                name = Path(p["image"]).stem[:16]
                line = f"L{p.get('layer',0)} {name} s={p.get('scale',1):.2f}"
                self.screen.blit(self.font_sm.render(line, True, col), (px + 12, y))
                y += 18
                if y > self.H - 200:
                    break

            y = self.H - 190
            helps = [
                "A : tambah prop (cycle)",
                "Del : hapus prop",
                "[ ] : layer - / +",
                "+/- / Scroll : scale",
                "Drag : pindah posisi",
            ]
            for h in helps:
                self.screen.blit(self.font_sm.render(h, True, GRAY), (px + 10, y))
                y += 16

        elif self.mode == 1:  # SPAWN
            self.screen.blit(self.font_sm.render(f"Spawn points: {len(self.cfg['spawn_points'])}", True, GRAY), (px + 10, y))
            y += 22
            helps = [
                "Klik kiri : tambah titik",
                "Drag : pindah",
                "Klik kanan : hapus",
                "0-3 : set layer",
            ]
            for h in helps:
                self.screen.blit(self.font_sm.render(h, True, GRAY), (px + 10, y))
                y += 18

            if self.selected and isinstance(self.selected, dict) and "id" in self.selected:
                s = self.selected
                y += 10
                self.screen.blit(self.font_sm.render(f"ID: {s['id']}", True, YELLOW), (px + 10, y))
                y += 16
                self.screen.blit(self.font_sm.render(f"Pos: {s['x']}, {s['y']}", True, YELLOW), (px + 10, y))
                y += 16
                self.screen.blit(self.font_sm.render(f"Layer: {s.get('layer',0)}", True, YELLOW), (px + 10, y))

        else:  # UI
            helps = [
                "Klik elemen : pilih",
                "Drag : pindah",
                "Scroll : ubah ukuran",
                "",
                "Elemen:",
                "  • Nenek (drop zone)",
                "  • Bubble",
                "  • Tombol Start/Pause",
                "    Resume/Restart/Quit",
            ]
            for h in helps:
                self.screen.blit(self.font_sm.render(h, True, GRAY), (px + 10, y))
                y += 17

        # Bottom status
        y = self.H - 70
        pygame.draw.line(self.screen, PANEL2, (px + 5, y), (px + self.PANEL_W - 5, y), 1)
        y += 8
        dirty_txt = "* belum disave" if self.dirty else "tersimpan"
        self.screen.blit(self.font_sm.render(dirty_txt, True, RED if self.dirty else GREEN), (px + 10, y))
        y += 18
        self.screen.blit(self.font_sm.render("S=Save  L=Reload  TAB=Mode", True, GRAY), (px + 10, y))

        # Toast
        if self.msg_timer > 0:
            t = self.font_b.render(self.message, True, GREEN)
            self.screen.blit(t, (px + 10, self.H - 100))

    def draw(self):
        self.draw_scene()
        self.draw_panel()
        pygame.display.flip()

    # ========== INPUT ==========
    def handle(self):
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                self.running = False

            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    if self.dirty:
                        self.toast("Tekan S dulu atau ESC lagi", 2)
                        # simple: second ESC force quit
                        self.dirty = False
                    else:
                        self.running = False
                elif e.key == pygame.K_s:
                    self.save()
                elif e.key == pygame.K_l:
                    self.cfg = self.load()
                    self._rebuild_prop_surfs()
                    self.selected = None
                    self.dirty = False
                    self.toast("Reloaded")
                elif e.key == pygame.K_TAB:
                    self.mode = (self.mode + 1) % 3
                    self.selected = None
                    self.toast(f"Mode: {MODES[self.mode]}")

                # Mode specific
                if self.mode == 0:
                    if e.key == pygame.K_a:
                        self.add_prop()
                    elif e.key == pygame.K_DELETE and self.selected in self.cfg["props"]:
                        self.cfg["props"].remove(self.selected)
                        self.selected = None
                        self.dirty = True
                        self._rebuild_prop_surfs()
                    elif e.key == pygame.K_LEFTBRACKET and self.selected in self.cfg["props"]:
                        self.selected["layer"] = max(0, self.selected.get("layer", 0) - 1)
                        self.dirty = True
                    elif e.key == pygame.K_RIGHTBRACKET and self.selected in self.cfg["props"]:
                        self.selected["layer"] = self.selected.get("layer", 0) + 1
                        self.dirty = True
                    elif e.key in (pygame.K_EQUALS, pygame.K_PLUS) and self.selected in self.cfg["props"]:
                        self.selected["scale"] = round(min(3.0, self.selected.get("scale", 1) + 0.05), 2)
                        self._rebuild_prop_surfs()
                        self.dirty = True
                    elif e.key == pygame.K_MINUS and self.selected in self.cfg["props"]:
                        self.selected["scale"] = round(max(0.1, self.selected.get("scale", 1) - 0.05), 2)
                        self._rebuild_prop_surfs()
                        self.dirty = True

                if self.mode == 1 and self.selected and "id" in self.selected:
                    if e.key in (pygame.K_0, pygame.K_1, pygame.K_2, pygame.K_3):
                        self.selected["layer"] = e.key - pygame.K_0
                        self.dirty = True

            elif e.type == pygame.MOUSEBUTTONDOWN:
                mx, my = e.pos
                if mx >= self.W:  # klik panel → ignore scene
                    continue

                if self.mode == 0:  # PROPS
                    if e.button == 1:
                        hit = self.hit_prop((mx, my))
                        self.selected = hit
                        self.dragging = hit is not None
                    elif e.button == 4 and self.selected in self.cfg["props"]:  # scroll up
                        self.selected["scale"] = round(min(3.0, self.selected.get("scale", 1) + 0.05), 2)
                        self._rebuild_prop_surfs()
                        self.dirty = True
                    elif e.button == 5 and self.selected in self.cfg["props"]:
                        self.selected["scale"] = round(max(0.1, self.selected.get("scale", 1) - 0.05), 2)
                        self._rebuild_prop_surfs()
                        self.dirty = True

                elif self.mode == 1:  # SPAWN
                    if e.button == 1:
                        hit = self.hit_spawn((mx, my))
                        if hit:
                            self.selected = hit
                            self.dragging = True
                        else:
                            new_id = max([s["id"] for s in self.cfg["spawn_points"]], default=0) + 1
                            sp = {"id": new_id, "x": mx, "y": my, "layer": 1}
                            self.cfg["spawn_points"].append(sp)
                            self.selected = sp
                            self.dirty = True
                    elif e.button == 3:
                        hit = self.hit_spawn((mx, my))
                        if hit:
                            self.cfg["spawn_points"].remove(hit)
                            if self.selected is hit:
                                self.selected = None
                            self.dirty = True

                elif self.mode == 2:  # UI
                    if e.button == 1:
                        hit = self.hit_ui((mx, my))
                        if hit:
                            self.selected = hit[1]
                            self.dragging = True
                    elif e.button in (4, 5) and self.selected:
                        delta = 4 if e.button == 4 else -4
                        if "radius" in self.selected:
                            self.selected["radius"] = max(20, self.selected["radius"] + delta)
                            self.dirty = True
                        elif "width" in self.selected:
                            self.selected["width"] = max(40, self.selected["width"] + delta)
                            self.selected["height"] = max(30, self.selected.get("height", 50) + delta // 2)
                            self.dirty = True
                        elif "w" in self.selected:
                            self.selected["w"] = max(40, self.selected["w"] + delta)
                            self.selected["h"] = max(30, self.selected["h"] + delta // 2)
                            self.dirty = True

            elif e.type == pygame.MOUSEBUTTONUP:
                if e.button == 1:
                    self.dragging = False

            elif e.type == pygame.MOUSEMOTION and self.dragging and self.selected:
                mx, my = e.pos
                if mx < self.W:
                    if isinstance(self.selected, dict):
                        if "radius" in self.selected or "width" in self.selected or "w" in self.selected or "id" in self.selected or "image" in self.selected:
                            self.selected["x"] = mx
                            self.selected["y"] = my
                            self.dirty = True

    def add_prop(self):
        if not self.available_props:
            self.toast("Tidak ada file di assets/props/")
            return
        # Cycle: ambil yang belum dipakai, atau random
        used = {p["image"] for p in self.cfg["props"]}
        candidates = [p for p in self.available_props if p not in used] or self.available_props
        img_path = candidates[0]
        new_p = {
            "id": Path(img_path).stem + f"_{len(self.cfg['props'])}",
            "image": img_path,
            "x": self.W // 2,
            "y": self.H // 2,
            "layer": 1,
            "scale": 1.0,
            "anchor": "center"
        }
        self.cfg["props"].append(new_p)
        self.selected = new_p
        self._rebuild_prop_surfs()
        self.dirty = True
        self.toast(f"Tambah: {Path(img_path).stem}")

    def update(self, dt):
        if self.msg_timer > 0:
            self.msg_timer -= dt

    def run(self):
        while self.running:
            dt = self.clock.tick(60) / 1000.0
            self.handle()
            self.update(dt)
            self.draw()
        pygame.quit()

if __name__ == "__main__":
    print("=" * 50)
    print("  Nenek Di Dapur - Scene Editor")
    print("  TAB = ganti mode | S = save | L = reload")
    print("=" * 50)
    Editor().run()
