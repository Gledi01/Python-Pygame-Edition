#!/usr/bin/env python3
"""
Nenek Di Dapur - Cozy Find & Drag Game
Semua posisi & layer diatur lewat editor.py → config/scene.json
"""

import pygame
import json
import random
import sys
from pathlib import Path

BASE = Path(__file__).parent
ASSETS = BASE / "assets"
OBJECTS_DIR = ASSETS / "objects"
CONFIG_PATH = BASE / "config" / "scene.json"

# Colors
WHITE = (255, 255, 255)
BLACK = (15, 12, 10)
CREAM = (255, 248, 220)
WARM = (139, 90, 43)
SOFT_RED = (220, 80, 80)
SOFT_GREEN = (90, 190, 110)
SOFT_YELLOW = (255, 220, 90)
BUBBLE_BG = (255, 255, 245)

def load_scene():
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def scan_objects():
    objs = {}
    if not OBJECTS_DIR.exists():
        OBJECTS_DIR.mkdir(parents=True)
        return objs
    for f in OBJECTS_DIR.iterdir():
        if f.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp"):
            try:
                img = pygame.image.load(str(f)).convert_alpha()
                max_s = 68
                w, h = img.get_size()
                sc = min(max_s / max(w, 1), max_s / max(h, 1), 1.0)
                if sc < 1.0:
                    img = pygame.transform.smoothscale(img, (int(w * sc), int(h * sc)))
                objs[f.stem] = img
            except Exception as e:
                print("Gagal load object:", f.name, e)
    print(f"[Game] {len(objs)} objek dimuat")
    return objs

class GameObject:
    def __init__(self, name, image, pos, spawn_id):
        self.name = name
        self.image = image
        self.rect = image.get_rect(center=pos)
        self.spawn_id = spawn_id
        self.dragging = False
        self.offset = (0, 0)
        self.origin = pos
        self.visible = True

    def draw(self, screen):
        if self.visible:
            screen.blit(self.image, self.rect)

    def start_drag(self, mpos):
        if self.visible and self.rect.collidepoint(mpos):
            self.dragging = True
            self.offset = (self.rect.centerx - mpos[0], self.rect.centery - mpos[1])
            return True
        return False

    def update_drag(self, mpos):
        if self.dragging:
            self.rect.center = (mpos[0] + self.offset[0], mpos[1] + self.offset[1])

    def stop_drag(self):
        self.dragging = False

    def reset(self):
        self.rect.center = self.origin
        self.dragging = False

class Button:
    def __init__(self, cfg, font):
        self.cfg = cfg
        self.font = font
        self.rect = pygame.Rect(0, 0, cfg["w"], cfg["h"])
        self.rect.center = (cfg["x"], cfg["y"])
        self.text = cfg.get("text", "")
        self.hover = False

    def draw(self, screen):
        col = (255, 200, 80) if self.hover else (200, 150, 60)
        bg = (60, 40, 25) if self.hover else (45, 30, 20)
        pygame.draw.rect(screen, bg, self.rect, border_radius=10)
        pygame.draw.rect(screen, col, self.rect, 2, border_radius=10)
        t = self.font.render(self.text, True, CREAM)
        screen.blit(t, t.get_rect(center=self.rect.center))

    def collide(self, pos):
        return self.rect.collidepoint(pos)

class Game:
    def __init__(self):
        pygame.init()
        self.scene = load_scene()
        sc = self.scene["screen"]
        self.W, self.H = sc["width"], sc["height"]
        pygame.display.set_caption(sc.get("title", "Nenek Di Dapur"))
        self.screen = pygame.display.set_mode((self.W, self.H))
        self.clock = pygame.time.Clock()
        self.running = True

        self.font_lg = pygame.font.SysFont("comicsansms", 32, bold=True)
        self.font_md = pygame.font.SysFont("comicsansms", 22)
        self.font_sm = pygame.font.SysFont("comicsansms", 18)
        self.font_btn = pygame.font.SysFont("comicsansms", 24, bold=True)

        self.prop_surfs = []
        self._load_props()

        self.object_images = scan_objects()
        if not self.object_images:
            self._dummy_objects()

        btns = self.scene["ui"]["buttons"]
        self.btn_start = Button(btns["start"], self.font_btn)
        self.btn_pause = Button(btns["pause"], self.font_sm)
        self.btn_resume = Button(btns["resume"], self.font_btn)
        self.btn_restart = Button(btns["restart"], self.font_btn)
        self.btn_quit = Button(btns["quit"], self.font_btn)

        self.state = "menu"
        self.reset_play_state()

    def _load_props(self):
        self.prop_surfs = []
        for p in sorted(self.scene["props"], key=lambda x: x.get("layer", 0)):
            path = ASSETS / p["image"]
            if not path.exists():
                print("Prop hilang:", path)
                continue
            try:
                img = pygame.image.load(str(path)).convert_alpha()
                sc = p.get("scale", 1.0)
                if abs(sc - 1.0) > 0.01:
                    w = max(1, int(img.get_width() * sc))
                    h = max(1, int(img.get_height() * sc))
                    img = pygame.transform.smoothscale(img, (w, h))
                r = img.get_rect()
                if p.get("anchor", "center") == "center":
                    r.center = (p["x"], p["y"])
                else:
                    r.topleft = (p["x"], p["y"])
                self.prop_surfs.append((p.get("layer", 0), img, r))
            except Exception as e:
                print("Error prop:", p["image"], e)

    def _dummy_objects(self):
        cols = [("merah", (220, 60, 60)), ("hijau", (60, 180, 80)),
                ("biru", (60, 120, 220)), ("kuning", (240, 200, 40)),
                ("ungu", (160, 80, 200)), ("orange", (240, 140, 40))]
        for name, c in cols:
            s = pygame.Surface((50, 50), pygame.SRCALPHA)
            pygame.draw.circle(s, c, (25, 25), 22)
            pygame.draw.circle(s, WHITE, (25, 25), 22, 3)
            self.object_images[name] = s

    def reset_play_state(self):
        self.lives = 3
        self.score = 0
        self.level = 1
        self.time_left = 120.0
        self.base_time = 120.0
        self.message = ""
        self.msg_timer = 0
        self.dragging = None
        self.objects = []
        self.target_name = None
        self.target_img = None

    def start_game(self):
        self.reset_play_state()
        self.place_objects()
        self.pick_target()
        self.state = "playing"

    def place_objects(self):
        self.objects = []
        names = list(self.object_images.keys())
        points = self.scene["spawn_points"]
        if not names or not points:
            return
        n = min(len(names), len(points), 12)
        chosen_n = random.sample(names, n)
        chosen_p = random.sample(points, n)
        for name, pt in zip(chosen_n, chosen_p):
            obj = GameObject(name, self.object_images[name], (pt["x"], pt["y"]), pt["id"])
            self.objects.append(obj)

    def pick_target(self):
        alive = [o for o in self.objects if o.visible]
        if not alive:
            self.place_objects()
            alive = self.objects
        if not alive:
            self.target_name = None
            return
        self.target_name = random.choice(alive).name
        self.target_img = self.object_images[self.target_name]

    def grandma_rect(self):
        g = self.scene["ui"]["grandma"]
        return pygame.Rect(g["x"] - g["radius"], g["y"] - g["radius"],
                           g["radius"] * 2, g["radius"] * 2)

    def draw_props(self):
        for layer, surf, rect in self.prop_surfs:
            self.screen.blit(surf, rect)

    def draw_bubble(self):
        if not self.target_name or self.state not in ("playing", "paused"):
            return
        b = self.scene["ui"]["bubble"]
        bx, by, bw, bh = b["x"], b["y"], b["width"], b["height"]
        surf = pygame.Surface((bw + 24, bh + 36), pygame.SRCALPHA)
        pygame.draw.ellipse(surf, BUBBLE_BG, (0, 0, bw + 24, bh + 12))
        pygame.draw.ellipse(surf, (190, 170, 130), (0, 0, bw + 24, bh + 12), 3)
        pygame.draw.polygon(surf, BUBBLE_BG, [(bw//2, bh+8), (bw//2+28, bh+32), (bw//2+12, bh+8)])
        self.screen.blit(surf, (bx - 12, by - 8))
        if self.target_img:
            tw, th = self.target_img.get_size()
            self.screen.blit(self.target_img, (bx + (bw - tw)//2, by + (bh - th)//2 - 4))
        q = self.font_sm.render("?", True, WARM)
        self.screen.blit(q, (bx + bw - 8, by + 2))

    def draw_hud(self):
        if self.state not in ("playing", "paused"):
            return
        hud = self.scene["ui"]["hud"]
        bar = pygame.Surface((self.W, 64), pygame.SRCALPHA)
        bar.fill((20, 14, 10, 190))
        self.screen.blit(bar, (0, 0))

        for i in range(3):
            c = SOFT_RED if i < self.lives else (70, 55, 45)
            cx = hud["lives_x"] + i * 34
            cy = hud["lives_y"]
            pygame.draw.circle(self.screen, c, (cx, cy - 4), 10)
            pygame.draw.polygon(self.screen, c, [(cx, cy + 8), (cx - 11, cy - 2), (cx + 11, cy - 2)])

        sc = self.font_md.render(f"Skor: {self.score}", True, CREAM)
        lv = self.font_sm.render(f"Level {self.level}", True, SOFT_YELLOW)
        self.screen.blit(sc, (hud["score_x"], hud["score_y"]))
        self.screen.blit(lv, (hud["score_x"], hud["score_y"] + 24))

        mins = int(self.time_left) // 60
        secs = int(self.time_left) % 60
        col = SOFT_RED if self.time_left < 20 else CREAM
        tm = self.font_lg.render(f"{mins:02d}:{secs:02d}", True, col)
        self.screen.blit(tm, (hud["timer_x"], hud["timer_y"]))

        self.btn_pause.hover = self.btn_pause.collide(pygame.mouse.get_pos())
        self.btn_pause.draw(self.screen)

        if self.message and self.msg_timer > 0:
            col = SOFT_GREEN if "Benar" in self.message or "Level" in self.message else SOFT_RED
            msg = self.font_md.render(self.message, True, col)
            r = msg.get_rect(center=(self.W // 2, 85))
            bg = pygame.Surface((r.w + 24, r.h + 12), pygame.SRCALPHA)
            bg.fill((0, 0, 0, 170))
            self.screen.blit(bg, (r.x - 12, r.y - 6))
            self.screen.blit(msg, r)

    def draw_menu(self):
        ov = pygame.Surface((self.W, self.H), pygame.SRCALPHA)
        ov.fill((15, 10, 5, 160))
        self.screen.blit(ov, (0, 0))
        title = self.font_lg.render("Nenek Di Dapur", True, SOFT_YELLOW)
        sub = self.font_sm.render("Cari & serahkan objek yang diminta nenek", True, CREAM)
        self.screen.blit(title, title.get_rect(center=(self.W//2, 280)))
        self.screen.blit(sub, sub.get_rect(center=(self.W//2, 330)))
        mouse = pygame.mouse.get_pos()
        self.btn_start.hover = self.btn_start.collide(mouse)
        self.btn_start.draw(self.screen)
        tip = self.font_sm.render("Atur posisi semua elemen lewat: python editor.py", True, (140, 130, 110))
        self.screen.blit(tip, tip.get_rect(center=(self.W//2, 700)))

    def draw_pause(self):
        ov = pygame.Surface((self.W, self.H), pygame.SRCALPHA)
        ov.fill((10, 8, 5, 180))
        self.screen.blit(ov, (0, 0))
        t = self.font_lg.render("JEDA", True, SOFT_YELLOW)
        self.screen.blit(t, t.get_rect(center=(self.W//2, 320)))
        mouse = pygame.mouse.get_pos()
        for b in (self.btn_resume, self.btn_restart, self.btn_quit):
            b.hover = b.collide(mouse)
            b.draw(self.screen)

    def draw_gameover(self):
        ov = pygame.Surface((self.W, self.H), pygame.SRCALPHA)
        ov.fill((20, 8, 5, 200))
        self.screen.blit(ov, (0, 0))
        t = self.font_lg.render("GAME OVER", True, SOFT_RED)
        s = self.font_md.render(f"Skor: {self.score}   Level {self.level}", True, CREAM)
        self.screen.blit(t, t.get_rect(center=(self.W//2, 300)))
        self.screen.blit(s, s.get_rect(center=(self.W//2, 360)))
        mouse = pygame.mouse.get_pos()
        self.btn_restart.hover = self.btn_restart.collide(mouse)
        self.btn_quit.hover = self.btn_quit.collide(mouse)
        self.btn_restart.draw(self.screen)
        self.btn_quit.draw(self.screen)

    def draw(self):
        self.screen.fill(BLACK)
        self.draw_props()
        if self.state in ("playing", "paused"):
            for o in self.objects:
                o.draw(self.screen)
            self.draw_bubble()
            self.draw_hud()
        if self.state == "menu":
            self.draw_menu()
        elif self.state == "paused":
            self.draw_pause()
        elif self.state == "gameover":
            self.draw_gameover()
        pygame.display.flip()

    def check_drop(self, obj):
        if obj.rect.colliderect(self.grandma_rect()):
            if obj.name == self.target_name:
                self.score += 10 * self.level
                self.message = "Benar! Nenek senang"
                self.msg_timer = 1.4
                obj.visible = False
                if obj in self.objects:
                    self.objects.remove(obj)
                if len([o for o in self.objects if o.visible]) < 4:
                    self.place_objects()
                if self.score > 0 and (self.score // 10) % 3 == 0:
                    self.level_up()
                self.pick_target()
            else:
                self.lives -= 1
                self.message = "Salah! -1 nyawa"
                self.msg_timer = 1.4
                obj.reset()
                if self.lives <= 0:
                    self.state = "gameover"
        else:
            obj.reset()

    def level_up(self):
        self.level += 1
        self.base_time = max(40, 120 - (self.level - 1) * 12)
        self.time_left = self.base_time
        self.message = f"Level {self.level}! Lebih cepat!"
        self.msg_timer = 2.0
        self.place_objects()
        self.pick_target()

    def update(self, dt):
        if self.msg_timer > 0:
            self.msg_timer -= dt
            if self.msg_timer <= 0:
                self.message = ""
        if self.state == "playing":
            self.time_left -= dt
            if self.time_left <= 0:
                self.time_left = 0
                self.state = "gameover"

    def handle(self):
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                self.running = False
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    if self.state == "playing":
                        self.state = "paused"
                    elif self.state == "paused":
                        self.state = "playing"
                    elif self.state in ("menu", "gameover"):
                        self.running = False
                if e.key == pygame.K_p and self.state == "playing":
                    self.state = "paused"
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                pos = e.pos
                if self.state == "menu":
                    if self.btn_start.collide(pos):
                        self.start_game()
                elif self.state == "playing":
                    if self.btn_pause.collide(pos):
                        self.state = "paused"
                    else:
                        for o in reversed(self.objects):
                            if o.start_drag(pos):
                                self.dragging = o
                                self.objects.remove(o)
                                self.objects.append(o)
                                break
                elif self.state == "paused":
                    if self.btn_resume.collide(pos):
                        self.state = "playing"
                    elif self.btn_restart.collide(pos):
                        self.start_game()
                    elif self.btn_quit.collide(pos):
                        self.state = "menu"
                elif self.state == "gameover":
                    if self.btn_restart.collide(pos):
                        self.start_game()
                    elif self.btn_quit.collide(pos):
                        self.state = "menu"
            elif e.type == pygame.MOUSEBUTTONUP and e.button == 1:
                if self.dragging and self.state == "playing":
                    self.check_drop(self.dragging)
                    self.dragging.stop_drag()
                    self.dragging = None
            elif e.type == pygame.MOUSEMOTION:
                if self.dragging:
                    self.dragging.update_drag(e.pos)

    def run(self):
        while self.running:
            dt = self.clock.tick(60) / 1000.0
            self.handle()
            self.update(dt)
            self.draw()
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    print("=" * 50)
    print("  Nenek Di Dapur")
    print("  Editor: python editor.py")
    print("=" * 50)
    Game().run()
