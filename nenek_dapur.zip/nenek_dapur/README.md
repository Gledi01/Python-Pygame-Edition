# Nenek Di Dapur 🍳

Game cozy 1-scene (Pygame). Semua tata letak diatur lewat **editor visual**.

## Jalankan Game
```bash
python main.py
```

## Jalankan Editor
```bash
python editor.py
```

### Kontrol Editor
| Tombol | Fungsi |
|--------|--------|
| **TAB** | Ganti mode: PROPS → SPAWN → UI |
| **S** | Save ke `config/scene.json` |
| **L** | Reload |
| **ESC** | Keluar |

#### Mode PROPS (latar / sprite)
- Klik prop → pilih
- Drag → pindah
- **A** → tambah prop dari `assets/props/`
- **Del** → hapus
- **[ ]** → layer turun/naik
- **+/-** atau **Scroll** → scale

#### Mode SPAWN (titik muncul objek)
- **Klik kiri** → tambah titik
- Drag → pindah
- **Klik kanan** → hapus
- **0-3** → set layer

#### Mode UI
- Klik Nenek / Bubble / Tombol → pilih
- Drag → pindah posisi
- Scroll → ubah ukuran

## Struktur
```
nenek_dapur/
├── main.py              # Game
├── editor.py            # Scene Editor (full)
├── config/
│   └── scene.json       # Semua posisi, layer, tombol
├── assets/
│   ├── props/           # Sprite latar (layer-able)
│   │   └── kitchen_base.png
│   ├── objects/         # Objek interaktif (di-scan otomatis)
│   └── ui/              # (opsional)
└── README.md
```

## Cara Kerja Layer
- Props digambar urut dari layer kecil → besar
- Spawn points punya layer (untuk referensi)
- Background bukan 1 gambar utuh: taruh potongan sprite di `assets/props/`, atur layer & posisi di editor

## Alur Game
1. **Menu** → tombol MAIN
2. **Playing** → drag objek ke nenek, timer, 3 nyawa
3. **Pause** (tombol || atau ESC) → Lanjut / Ulangi / Keluar
4. **Game Over** → Ulangi / Keluar

Semua posisi tombol, nenek, bubble, spawn points, props → **bisa diatur di editor dan tersimpan**.
